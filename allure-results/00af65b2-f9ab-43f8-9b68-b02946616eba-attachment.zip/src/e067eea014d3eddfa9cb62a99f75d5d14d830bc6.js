import {test} from '@playwright/test'
test('iframe',async({page})=>{
    await page.goto("https://practice-automation.com/iframes/")
    const frame=page.frameLocator("#iframe-1")
    await page.locator("//a[text()='MCP']").click()
    await page.locator("//span[text()='installation']").click()
})